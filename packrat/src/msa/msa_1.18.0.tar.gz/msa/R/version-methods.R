setMethod("version", "MsaMetaData",
          function(object) object@version)
