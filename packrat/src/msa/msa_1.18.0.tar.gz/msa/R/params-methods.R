setMethod("params", "MsaMetaData", function(x) x@params)
