//
// File SplitCharVector2Matrix.h defining prototypes for SplitCharVector2Matrix.cpp
//

#ifndef _SplitCharVector2Matrix_H_

#define _SplitCharVector2Matrix_H_

RcppExport SEXP SplitCharVector2Matrix(SEXP xR, SEXP replR);

#endif
