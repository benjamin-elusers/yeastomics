library(testthat)
library(hablar)
test_check("hablar")
# Keep order of hablar.R for tests
