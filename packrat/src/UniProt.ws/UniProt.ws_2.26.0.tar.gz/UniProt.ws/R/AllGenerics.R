setGeneric("taxId", function(x) standardGeneric("taxId"))
setGeneric("taxId<-", signature="x", function(x, value) standardGeneric("taxId<-"))
## taxIdUniprots is not intended to be exported.
setGeneric("taxIdUniprots", function(x) standardGeneric("taxIdUniprots"))
setGeneric("db", function(x) standardGeneric("db"))
