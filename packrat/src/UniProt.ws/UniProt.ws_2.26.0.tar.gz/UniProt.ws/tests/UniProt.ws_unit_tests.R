BiocGenerics:::testPackage("UniProt.ws")
