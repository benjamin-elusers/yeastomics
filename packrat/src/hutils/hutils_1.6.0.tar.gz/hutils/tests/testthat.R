library(testthat)
library(hutils)

test_check("hutils")
